
#Librairies importées
import numpy as np 
import time as t
from matplotlib.pyplot import plot, show, legend
A = np.array([[0.0,3.0,2.0,2.0], [1.0,2.0,2.0,4.0], [1.0,1.0,2.0,1.0], [2.0,3.0,2.0,3.0]])
B = np.array([1.0,2.0,1.0,2.0]).T
#Taug = np.array([[1,1,1,1,1],[0,2,-5,0,-1],[0,0,1,-2,3],[0,0,0,4,-4]])


#### Pour pivot de gauss ####
def ResolutionSystTriSup(Taug):
    global nb_ligne, nb_colonnes
    nb_ligne, nb_colonnes = Taug.shape
    comptage=0
    liste_solutions = []
    v = Taug[nb_ligne-1][nb_colonnes-1]/Taug[nb_ligne-1][nb_colonnes-2]   # valeur de Xn qui nous permet de résoudre le reste du système
    liste_solutions.append(v)
    for i in range(2,nb_ligne+1):
        n = Taug[nb_ligne-i][nb_colonnes-1]
        for j in range(2,nb_colonnes+1):
            if ((nb_colonnes - j) > (nb_ligne - i)):
                #if abs(Taug[nb_ligne-i , nb_colonnes-j] - 0) <= 10**-10:
                n = n - Taug[nb_ligne-i , nb_colonnes-j]*liste_solutions[comptage]  #on bascule toutes les valeurs de l'autre coté sauf le X qu'on cherche à calculer.
                comptage+=1
        n = n / Taug[nb_ligne-i, nb_colonnes-i-1]  #on divise et on obtient la valeur d'une des inconnu du système
        v=n
        comptage = 0
        liste_solutions.append(v)
        X=np.asarray(liste_solutions)
    return X


'''
def GaussChoixPivotTotal(A,B):
    #définition de la matrice aug et ses propriétés
    matrice = np.c_[A,B]
    nb_ligne, nb_colonnes = matrice.shape
    #print(n,m)
c = np.copy(matrice[k,:])
matrice[k,:] = matrice[var,:]
matrice[var,:] = c
    for k in range (nb_colonnes-1):
        for i in range (k+1,nb_colonnes-1):
            for n in range (i,nb_colonnes-1):
                if abs(matrice[n,k]) > abs(matrice[k,k]):
                    print(matrice)
            for l in range (i, nb_ligne):
                if abs(Aaug[k,k]) > plusgrand:
                    plusgrand = abs(Aaug[k,l])
                    L_echange = l   
                    
                
                print(matrice)
                pivot = matrice[i,k]/matrice[k,k]

                matrice[i,:] = matrice[i,:] - pivot*matrice[k,:]


    solution = ResolutionSystTriSup(matrice)
    print(solution)
    return (solution)

'''

def GaussChoixPivotTotal(A,B):
    Aaug=np.c_[A,B]
    nb_ligne, nb_colonnes = np.shape(Aaug)
    #réduction de Gauss
    L_echange=0
    pivot = 0
    plusgrand = 0
    for k in range(0,nb_colonnes):
        for i in range(k+1,nb_ligne):
            if Aaug[k,k] == 0:
                print('passage')
                for l in range (i, nb_ligne):
                    if abs(Aaug[l,k]) > plusgrand:
                        print(Aaug[l,k])
                        plusgrand = abs(Aaug[l,k])
                        L_echange = l
                        a=0
                for c in range (i, nb_colonnes):
                    if abs(Aaug[k,c]) > plusgrand:
                        a=1
                        plusgrand = abs(Aaug[k,c])
                        L_echange = c

                if a==0:
                    c=Aaug[i-1,:].copy()
                    Aaug[i-1,:] = Aaug[L_echange,:]
                    Aaug[L_echange,:]= c
                    
                else:
                    c=Aaug[:,i-1].copy()
                    Aaug[:,i-1] = Aaug[:,L_echange]
                    Aaug[:,L_echange]= c
            
            pivot = (Aaug[i,k])/(Aaug[k,k])
            Aaug[i,:] = Aaug[i,:] - pivot * Aaug[k,:]
            
    return Aaug 




print(GaussChoixPivotTotal(A,B))