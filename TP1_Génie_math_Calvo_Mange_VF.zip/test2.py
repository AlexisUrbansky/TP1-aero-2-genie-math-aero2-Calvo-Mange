import numpy as np 
import time as t
from matplotlib.pyplot import plot, show, legend

A = np.array([[1,1,1,1], [2,4,-3,2], [-1,-1,0,-3], [1,-1,4,9]])
B = np.array([1,1,2,-8]).T
''''
A = np.array([[3,2,-1,4], [-3,-4,4,-2], [6,2,2,7], [9,4,2,18]])
B=np.array([[4,-5,-2,13]]).T
'''
def DecompositionLU(A):
    nb_ligne, nb_colonnes = np.shape(A)
    #création d'une matrice L vièrge
    n = nb_ligne

    L = np.random.rand(n, n)
    for k in range(0,n):
        for i in range(0,n):
            L[i,k] = 0

    #Set up pour faire une réduction de la matrice carrée A et réduction.
    #à chaque création du pivot il est ajouté à la matrice L
    pivot = 0

    for k in range(0,nb_colonnes):
        for i in range(k+1,nb_ligne):
            pivot = (A[i,k])/(A[k,k])
            L[i,i] = 1
            L[i,k] = pivot
            A[i,:] = A[i,:] - pivot * A[k,:] 
    L[0,0] = 1

    
    #print des résultats pour les vérifier, la matrice A est devenue la matrice U
    U = A
    print("la fonction U : \n")
    print(U)
    print("la fonction L : \n")
    print(L)
    return (U,L)

def random_mat(n):
    A = np.random.rand(n, n)
    B = np.random.rand(n)

    return A, B

#on prend pour essayer le programme, la matrice de l'exercice 4
#A = np.array([[3,2,-1,4], [-3,-4,4,-2], [6,2,2,7], [9,4,2,18]])
#Matrice provenant du TD contenant un pivot nul.
#A = np.array([[1,1,1,1], [2,4,-3,2], [-1,-1,0,-3], [1,-1,4,9]])
#DecompositionLU(A)



#def ResolutionLU(L,U,B):

def ResolutionSystTriSup(Taug):
    nb_ligne, nb_colonnes = np.shape(Taug)
    comptage=0
    liste_solutions = []
    v = Taug[nb_ligne-1][nb_colonnes-1]/Taug[nb_ligne-1][nb_colonnes-2]   # valeur de Xn qui nous permet de résoudre le reste du système
    liste_solutions.append(v)
    for i in range(2,nb_ligne+1):
        n = Taug[nb_ligne-i][nb_colonnes-1]
        for j in range(2,nb_colonnes+1):
            if ((nb_colonnes - j) > (nb_ligne - i)):
                #if abs(Taug[nb_ligne-i , nb_colonnes-j] - 0) <= 10**-10:
                n = n - Taug[nb_ligne-i , nb_colonnes-j]*liste_solutions[comptage]  #on bascule toutes les valeurs de l'autre coté sauf le X qu'on cherche à calculer.
                comptage+=1
        n = n / Taug[nb_ligne-i, nb_colonnes-i-1]  #on divise et on obtient la valeur d'une des inconnu du système
        v=n
        comptage = 0
        liste_solutions.append(v)
    return liste_solutions

def GaussChoixPivotPartiel(A,B):
    Aaug=np.c_[A,B]
    nb_ligne, nb_colonnes = np.shape(Aaug)
    print("la matrice juste augmentée est \n Aaug =")
    print(Aaug)
    #réduction de Gauss
    L_echange=0
    pivot = 0
    for k in range(0,nb_colonnes):
        for i in range(k+1,nb_ligne):
            print("valeur de k " + str(k))
            #exception si le pivot est nul
            if Aaug[i,k] == 0:
                print("valeur de k' " + str(k))
                plusgrand = 0
                for l in range (i+1, nb_ligne):
                    print("valeur de l " + str(l))
                    if abs(Aaug[l,k]) > plusgrand:
                        plusgrand = abs(Aaug[l,k])
                        L_echange = l
                    for c in range (k, nb_colonnes):
                        Aaug[i,c] , Aaug[L_echange,c] = Aaug[L_echange,c] , Aaug[i,c]
                        print(Aaug)              
                    
                pivot = (Aaug[i,k])/(Aaug[k,k])
                Aaug[i,:] = Aaug[i,:] - pivot * Aaug[k,:]     
                    

            else :
                pivot = (Aaug[i,k])/(Aaug[k,k])
                Aaug[i,:] = Aaug[i,:] - pivot * Aaug[k,:]

    print ("la matrice augmentée réduite est \n Aaug =")
    print (Aaug)
    solution = ResolutionSystTriSup(Aaug)
    print(solution)
    return (solution)

GaussChoixPivotPartiel(A,B)


